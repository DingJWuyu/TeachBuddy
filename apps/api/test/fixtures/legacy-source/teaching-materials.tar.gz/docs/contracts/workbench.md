# 工作台契约入口

状态：`AUTH-CONTRACT-CORRECTION@1 / FROZEN`。当前 OpenAPI 为 `0.1.0-candidate.2`，与认证 `1.0.0-rc.2` 同一候选提交消费；页面头接缝已由限定独立审查冻结。适用行为仍为 [first-flow](../user-stories/first-flow.md)、[UX U0-U7](../ux/first-flow.md)。原型参考 [Mixed manifest](../../prototype/behavior/manifest.md)，不将 Draft 模块稿声明为 Accepted。

精确 HTTP、字段、枚举、边界、错误与例子唯一归 [first-flow.openapi.yaml](workbench/first-flow.openapi.yaml)。本页拥有跨操作语义，[契约用例](workbench/first-flow-cases.md)拥有交换序列和固定样本；实现两侧消费同一 OpenAPI，不另写竞争 schema。下游任务见 [B12-B15](../plans/tasks/first-flow-implementation.md)。

## 消费版本与验收范围

| 消费线 | 固定输入 | 适用范围与接续条件 |
| --- | --- | --- |
| 已冻结首流 | B11 `9aee091a34ba2eb311b51299d9beed78a032d026`，OpenAPI `0.1.0-candidate.1`；独立审查 `b62034eb6661f99127d0e4b1407174260a139089` 的 [review](../acceptance/evidence/B11/v1/review.md) | 保留其固定源 `59a14e95bab667e0a01b8d62f6e87e018ddb1c5f`、B10 `8e9b230c56c7384521b122a7a80b6b07e18c852c`。旧冻结只覆盖该版本，未验页面头。 |
| 现有测试身份首流 | 运行任务输入 `b938f8af0b8152718f5063d4326d494bf8b5426c`；B12 交付 `3c8d1b3210f3d35e45eaca8141040852e3cb865c`，其 author 固定实现 `feb64304a58077de50bc16507f8c271c60ca3ee8` | B12-B16 可继续按旧固定契约完成 `real-api/test-principal`；不要求其模拟认证页面绑定，也不能据此声明新 schema 或 real-auth 通过。 |
| 真实认证接续 | 工作台 `0.1.0-candidate.2` + 认证 `1.0.0-rc.2`；两份文件均取 [correction 回执](../acceptance/evidence/AUTH-CONTRACT/v1/correction.md) 的实际 `result_revision`，由 [限定独立审查](../acceptance/evidence/AUTH-CONTRACT/v1/correction-review.md) 固定 | 新增所有 15 个受保护操作的必填 PageContext。认证前后端、A10/A11 按同版输入接续；新版本验收另留证据，旧 PASS 不适用。 |

直接受影响的是 B12 公共 schema/身份门禁、B14 请求 transport/替身、B15 集成与 B16 的 HTTP 验收口径，以及认证前后端、A10/A11/A12。B13 业务 body、principal、事务和返回 schema 保持，但切到新版时其 HTTP fixture 同样必须携带页面头。旧固定任务继续使用旧 commit 内的契约；读取当前文件的消费者按新版执行，不能以 test-principal 为由把当前必填头改为可选。根决定何时切换和固定各候选；本页不改 DAG 或派发状态。

切换后的公共 schema/客户端检查覆盖全部 15 个操作；真实认证集成按 [C19-C21](workbench/first-flow-cases.md#真实认证页面接缝)核验读写、目录/context、拒绝及刷新恢复，并回归原 WB-001 至 WB-019 中受影响的身份、来源、重试和账户隔离路径。新增要求的独立验收归 A12；如 B15/B16 提前消费新版，也必须另记 schema 版本与 identity_mode，不能沿用旧 PASS。

## 身份与 HTTP

沿用 [认证 OpenAPI](auth.openapi.yaml) 中已有的同源 HTTPS、Cookie、固定保护头、完整来源校验、直接 JSON 成功结果、`application/problem+json` 失败、`Cache-Control: no-store`、请求拒绝未知字段与隐式转换、响应允许附加字段的风格。工作台错误使用独立 `/problems/workbench/*` 命名空间。浏览器不拼接 Bearer、不接收 accountId 参数；写请求缺来源/保护头在任何业务变更前拒绝。

认证消费上述同版候选的 [auth.md](auth.md)，其真实实现和交付另行验收。登录、退出、Cookie 寿命和认证身份响应由认证拥有。服务端接入边界为 `resolvePrincipal(request) -> { accountKey: string } | null`（允许 Promise），accountKey 来自已验证身份的稳定账户映射。工作台 `getWorkbenchContext` 只返回缓存分区键，不构成认证 API。客户端传回此键不能证明身份。所有读、列表、来源、引用、复制、恢复、请求重放均按该身份授权；无身份 401，不属于该账户或不存在的对象统一 404，不泄漏是否存在。

当前全部受保护操作显式外引认证 PageContext，页面头由认证 transport 附加。缺失、形状非法、无当前页 active 绑定或身份失效均返回工作台 401 `unauthenticated`；服务存储不可用仍为工作台 503 `temporarily-unavailable`。写请求的来源/保护头拒绝先于身份，GET 不增加来源/保护头要求。认证端点的 409 `browser-context-required` 不传播为工作台错误。页面头单独不能授权，记住我 Cookie 在新页未经 restore 也不能直接授权。

客户端先获取上下文才能读取本地账户数据。响应还要属于当前身份代次、请求对象及提交版本，迟到旧响应不能回填新账户或覆盖更新草稿。A10/A11 负责把真实认证映射到此边界；B12 只提供隔离测试 runner 的可信 principal，生产配置发现测试身份立即失败退出，无请求头/查询参数/浏览器 accountId 后门。

## 内容与对象

题目、自定义环节、引用及备课使用稳定 UUID；题目/备课 ID 由服务器创建，环节/引用 ID 由客户端创建，仅用于对象标识与重试，不代表授权。对象创建 `version=1`，每次有效写入严格增加 1，包括删除/恢复；相同内容的新写请求也增加版本。数组顺序就是显示顺序，同份备课所有环节 ID、引用 ID 各自全局唯一；重排保持 ID。时间为服务端 UTC，浏览器按本地时间呈现。

数学文档 v1 是有序段落/独立公式，段落内为文字/行内公式。选项与小问可以用任意段落编写，不要求固定题型。题面与答案为两个独立文档，长期笔记独立保存；本课备注在引用上。原始粘贴文本逐字保留，编辑整理题目不会改原稿。服务端保存公式源，不执行 HTML/脚本；渲染失败不销毁源内容。后续图片/资产通过新版明确节点和账户内文件引用加入，不预置任意 HTML、通用 attrs 或资产平台。

创建普通题目可有粘贴来源；来源创建后不改。复制时编辑器以原题题面/答案/标题初始化，笔记为空、标记关闭；首个保存将改编后的完整输入与所用原题版本一起提交，服务器新建独立 ID，来源保存原题 ID、所用版本和内容快照。复制之后两题独立编辑；读取原题的衍生列表可以反向找到副本，原题软删除也不破坏来源快照。直接修改不生成新题或来源。

列表一次返回当前账户匹配的全部结果，不做无消费者的分页设施；按 `updatedAt` 降序、ID 升序稳定排序。题库搜索对标题、题面文字和公式源、长期笔记执行去首尾空白后的不区分大小写子串匹配，不搜索答案和来源；备课搜索标题及正文文字/公式，不搜索引用快照和备注。过滤默认 active，deleted 只列软删除内容。单对象读取允许返回本账户 tombstone 内容以恢复；编辑已删除对象返回 409 object-deleted。

## 引用、更新与删除

备课是一个版本化聚合：课题、开头文稿、自定环节、环节内文稿与题目引用、本课材料一起提交，全部成功或全部失败。本课材料为未安排环节的引用集合；同一引用移动位置保留 ID、快照与备注。删除环节时请求必须明确将引用移入材料或移除；遗漏的环节/引用视为主动移除，不留服务端隐式搬迁规则。

引用保存题目 ID、采用版本及由服务端取得的题面/答案/标题快照，排除题库笔记。新引用必须指向本账户未删除题目的当前版本；来源已变返回 reference-version-conflict，不偷偷采用最新。已有引用的 ID、questionId、questionVersion 未变时保留服务端快照，即使原题已删除仍可保存备课。已有引用 ID 不得改指另一题；改变 questionVersion 表示明确采用题目当前版本。所有引用解析与备课写入在同一事务中完成。

读取备课同时给出每个来源的 active/deleted 状态及最新版本。该派生状态变化不增加备课版本、不改快照；显示“有更新”只在 active 且版本不同。使用位置从 lessons 的公共查询返回活动备课位置，questions 不读 lessons 表。同题在一个位置可有多个独立引用，普通取题交互去重，“再放一次”才显式创建另一个。请求幂等防重复和老师主动重复引用是两件事。

软删除保留原内容、ID、来源、引用及操作记录，无自动清理期限。本批没有永久删除。删除题目不级联删副本或备课快照，删除备课不删题目；恢复只改 deletedAt 并增加版本，不重建 ID。恢复原题不自动替换已采用快照。后续整体备份需覆盖这些记录，F62 定义带走/恢复流程。

## 写入、冲突与未知结果

所有写操作携带 `Idempotency-Key` UUID。作用域为可信账户，键绑定 HTTP 方法、规范路径和解析后 JSON 的字段值（对象键序无关，数组序有关）；键只代表一次逻辑提交。业务变更与成功状态码/结果一起原子持久保存，跨进程重启可重放；本批保留至账户数据被明确清理，不设置会使离线重试失效的 TTL。

处理顺序：来源/保护与身份、JSON/基本 schema、已成功请求键、对象归属、当前版本及业务校验、原子写入。相同键/同请求重放原成功结果，先于最新版本校验；相同键/不同请求返回 409 idempotency-key-reused。并发同键只有一次提交，后者等待事务完成并重放；事务失败可回滚并用同键重试。失败不记为成功操作，也不消耗该键。跨账户相同键互不影响。

编辑、删除、恢复、复制均携带期望版本。版本不符 409 version-conflict；响应给本账户对象当前版本，客户端再读取用于对照。新/更新引用的来源版本冲突携带对应 questionId 与当前版本；外账户源只返回 404。复制原题改变不能悄悄复制新版。批量取题通过一次备课 PUT 原子提交，不能部分添加。

“已保存”仅能由匹配的已知 2xx JSON（包含 ID/version，且等于本次提交结果）确认，并且当前编辑器没有新的未提交输入。本地缓存写入、开始 fetch、断线或 5xx 均不足。超时、断线、未知错误类型、无效响应或 5xx 一律视为结果未确认。客户端持久保留原键、原请求和基线，先用同键同请求重试确认；不能新建另一个逻辑请求“赌”前次失败。重放得到旧版本成功后确认的是旧提交，再 GET 当前对象，不降级已有较新读数。新输入留在独立草稿中，确认后再以明确基线提交。

业务版本冲突只允许老师对照整理后新键提交；没有自动覆盖、后台合并或盲目重放。明确 4xx 失败可修正后用新键提交。401 后暂停写入，原请求留原账户，重新验证相同账户才可确认。

## 覆盖与归属

| 场景 | 操作/定义 | 主要负责人 |
| --- | --- | --- |
| WB-001、002、003、014 | create/list/get/updateQuestion、Document、source | B13 数据；B14 编辑/呈现 |
| WB-004 | copyQuestion、listDerivatives | B13/B14 |
| WB-005、006、007 | create/updateLesson、QuestionReference、listQuestionUsages | B13/B14 |
| WB-008、009 | updateLesson、setQuestionDeletion、setLessonDeletion | B13/B14 |
| WB-011、012、013、016、018 | 写入协议、Problem、可信身份 | B12 基础；B13 业务；B14 反馈；B15 真故障 |
| WB-010、015、017 | 本地草稿/现场、U0-U7、身份代次 | B14，B15 真服务复验 |
| WB-019 | 独立存储、迁移/启动/构建、同源 HTTPS | B12；B15 复现 |

数据/模块接缝和共享写者只见 [架构](../arch/first-flow.md)，无需引入认证未定义字段或 pi 专属 API。

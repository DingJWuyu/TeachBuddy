/** T50/v1 static catalog v2. Both runtime projections consume this source. */
export const moduleCatalogVersion = 2;
export const moduleCatalog = Object.freeze([
  {
    "id": "questions",
    "name": "题库",
    "path": "/questions",
    "navigation": "sidebar",
    "auxiliaryPanel": true,
    "requires": []
  },
  {
    "id": "lessons",
    "name": "备课",
    "path": "/lessons",
    "navigation": "sidebar",
    "auxiliaryPanel": true,
    "requires": [
      "questions.readForReference"
    ]
  },
  {
    "id": "classes",
    "name": "班级",
    "path": "/classes",
    "navigation": "sidebar",
    "auxiliaryPanel": true,
    "requires": [
      "questions.readForReference",
      "lessons.readForTeachingLink"
    ]
  },
  {
    "id": "schedule",
    "name": "日程",
    "path": "/calendar",
    "navigation": "top",
    "auxiliaryPanel": true,
    "requires": [
      "classes.readClass",
      "classes.readRecord",
      "lessons.readForTeachingLink"
    ]
  }
].map(entry => Object.freeze({ ...entry, requires: Object.freeze(entry.requires) })));
export const modulePorts = Object.freeze({
  'questions.readForReference': { provider: 'questions', port: 'readForReference' },
  'lessons.readForTeachingLink': { provider: 'lessons', port: 'readForTeachingLink' },
  'classes.readClass': { provider: 'classes', port: 'readClass' },
  'classes.readRecord': { provider: 'classes', port: 'readRecord' }
});
export const moduleCatalogIdPattern = /^[a-z][a-z0-9-]*$/;
export const moduleCatalogPathPattern = /^\/[a-z][a-z0-9-]*$/;
export const moduleCatalogNavigationValues = Object.freeze(['sidebar', 'top']);

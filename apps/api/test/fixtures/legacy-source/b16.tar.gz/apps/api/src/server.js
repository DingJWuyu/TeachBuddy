import fs from 'node:fs';
import http from 'node:http';
import https from 'node:https';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApp } from './app.js';

/**
 * Startup path for a real process.
 *
 * Module discovery and pending migrations run before the socket opens, so a
 * catalog/dependency/migration failure stops startup instead of serving a
 * half-prepared database. The same origin serves the API and, when configured,
 * the built Web assets; HTTPS is used whenever a certificate is configured.
 */
export function createHttpServer(context) {
  const tls = context.env.workbench?.tls;
  if (tls?.cert && tls?.key) {
    return https.createServer(
      { cert: fs.readFileSync(tls.cert), key: fs.readFileSync(tls.key) },
      context.app
    );
  }
  return http.createServer(context.app);
}

export async function startServer(options = {}) {
  const context = createApp(options);

  try {
    await context.workbench.initialize();
  } catch (error) {
    context.dataStore.close();
    throw error;
  }

  const server = createHttpServer(context);
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(context.env.port, resolve);
  });

  const scheme = context.env.workbench?.tls ? 'https' : 'http';
  const origin = `${scheme}://localhost:${context.env.port}`;
  console.log(`${context.env.appName} running on ${origin}`);

  return { ...context, server, origin };
}

const __filename = fileURLToPath(import.meta.url);
const isMainModule = process.argv[1] && path.resolve(process.argv[1]) === __filename;

if (isMainModule) {
  startServer().catch((error) => {
    // Write synchronously so the failure reason survives process.exit.
    fs.writeSync(2, `[startup] ${error?.stack ?? error?.message ?? String(error)}\n`);
    process.exit(1);
  });
}

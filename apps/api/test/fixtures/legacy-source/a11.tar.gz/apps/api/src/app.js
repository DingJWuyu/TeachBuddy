import express from 'express';
import path from 'node:path';
import { workbenchPaths } from '@refatos/shared';
import { createEnv, env as defaultEnv } from './config/env.js';
import { createDataStore } from './core/dataStore.js';
import { createAuthCodeSender } from './core/mail.js';
import { notFound } from './middleware/notFound.js';
import { errorHandler } from './middleware/errorHandler.js';
import { createWorkbench } from './workbench/index.js';
import { createAuthModule } from './features/auth/index.js';
import { migrations } from './features/auth/migrations/index.js';
import { contractError, problems } from './workbench/problems.js';

export function createApp(options = {}) {
  const runtimeEnv = options.env ? createEnv(options.env) : defaultEnv;
  // Test identities remain available only to explicitly isolated regression runners.
  const testIdentity = runtimeEnv.nodeEnv === 'test' && runtimeEnv.workbench.mode === 'test-principal';
  let authModule;
  if (!testIdentity) {
    if (!runtimeEnv.authCodeSecret) throw new Error('AUTH_CODE_SECRET is required.');
    const origin = new URL(runtimeEnv.workbench.publicOrigin);
    if (origin.protocol !== 'https:' || origin.origin !== runtimeEnv.workbench.publicOrigin) {
      throw new Error('WORKBENCH_PUBLIC_ORIGIN must be an exact HTTPS origin.');
    }
    runtimeEnv.workbench.trustedOrigins = [origin.origin];
    runtimeEnv.workbench.resolvePrincipal = async (request) => {
      if (!authModule) throw contractError(problems.temporarilyUnavailable());
      try {
        return await authModule.resolvePrincipal(request);
      } catch (error) {
        if (['/problems/auth/account-store-unavailable', '/problems/auth/session-store-unavailable'].includes(error.problem?.type)) {
          throw contractError(problems.temporarilyUnavailable());
        }
        throw error;
      }
    };
  }
  const workbench = options.workbench ?? createWorkbench({ env: runtimeEnv, logger: options.workbenchLogger });
  let dataStore;
  try {
    dataStore = options.dataStore ?? createDataStore(runtimeEnv, { db: workbench.db });
    if (!testIdentity) {
      workbench.migrations.run([{ moduleId: 'auth', migrations }], { knownModuleIds: ['auth'] });
      const gaps = workbench.db.prepare('SELECT accountId, reason FROM auth_legacy_gaps').all();
      if (gaps.length) {
        throw new Error('Resolve auth_legacy_gaps in an isolated database before startup: ' + JSON.stringify(gaps));
      }
      authModule = createAuthModule({
        db: workbench.db,
        publicOrigin: runtimeEnv.workbench.publicOrigin,
        codeSecret: runtimeEnv.authCodeSecret,
        isRegistrationOpen: () => runtimeEnv.registrationOpen,
        sendCode: options.sendCode ?? createAuthCodeSender(runtimeEnv),
        now: options.now
      });
    }
  } catch (error) {
    workbench.close();
    throw error;
  }
  const app = express();
  if (authModule) app.use('/api/auth', authModule.router);
  app.use(workbenchPaths.context, workbench.contextRouter);
  app.use(workbenchPaths.modules, workbench.modulesRouter);
  app.get(workbenchPaths.modules, ...workbench.catalogHandler);
  app.get('/api/health', (req, res) => res.json({ app: runtimeEnv.appName, status: 'ok' }));

  // Single-origin entry: when a web build is configured, serve it from the same
  // origin as the API (SPA fallback for non-API GETs only).
  if (runtimeEnv.workbench.webDist) {
    const webDist = path.resolve(runtimeEnv.workbench.webDist);
    const indexPath = path.join(webDist, 'index.html');
    app.use(express.static(webDist, { index: ['index.html'] }));
    app.use((req, res, next) => {
      if (req.method !== 'GET' || req.path.startsWith('/api/')) return next();
      return res.sendFile(indexPath);
    });
  }

  app.use(notFound);
  app.use(errorHandler);

  return { app, dataStore, env: runtimeEnv, workbench };
}
